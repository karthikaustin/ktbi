package com.maveric.seleniumconcepts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class Seliniumwebelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new InternetExplorerDriver();
		driver.get("http://connect.maveric-systems.com/index.php/site/login");
		WebElement userNameEle= driver.findElement(By.id("LoginForm_username"));
		userNameEle.sendKeys("Karthikeyanms");
		WebElement userPasswordEle= driver.findElement(By.id("LoginForm_password"));
		userPasswordEle.sendKeys("Time$heetapr2019");
		WebElement loginEle= driver.findElement(By.id("LoginForm_password"));
		loginEle.click();
		
	}

}
