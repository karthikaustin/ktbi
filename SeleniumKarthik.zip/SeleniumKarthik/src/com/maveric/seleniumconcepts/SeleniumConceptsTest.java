package com.maveric.seleniumconcepts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class SeleniumConceptsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//WebDriver driver = new ChromeDriver();
//WebDriver driver = new FirefoxDriver();
WebDriver driver = new InternetExplorerDriver();
driver.get("http://connect.maveric-systems.com/index.php/site/login");
String title= driver.getTitle();
System.out.println(title);

String url= driver.getCurrentUrl();
System.out.println(url);

String pagesource=driver.getPageSource();
if(pagesource.contains("Forgot Your Password")) {
	System.out.println("Test Passed");
}else {
		System.out.println("Test Failed");
}
}

	}


